# UCX Tournament — Android WebView App

A complete Android Studio (Kotlin) project that wraps **https://ucxtournament.vercel.app**
in a full-screen WebView with a splash screen, error/retry handling, and support for
Google Login, file uploads, camera/mic, geolocation, popups, downloads, and full-screen video.

## How to open

1. Open **Android Studio** (Hedgehog / Iguana or newer recommended).
2. `File > Open` → select the `UCXTournament` project folder.
3. Let Gradle sync. If prompted about the Gradle wrapper jar, choose
   `File > Sync Project with Gradle Files` — Android Studio will fetch the
   Gradle 8.4 distribution declared in `gradle/wrapper/gradle-wrapper.properties`
   automatically (the binary `gradle-wrapper.jar` isn't bundled here since it's a
   binary file; Android Studio regenerates it on first sync, or run
   `gradle wrapper` locally if you have Gradle installed).
4. Run on a device/emulator (`Shift+F10`).

## What's included

- **`SplashActivity`** — shows the provided splash image full-screen for ~2 seconds,
  then fades out and launches `MainActivity` (fade transition).
- **`MainActivity`** — full-screen `WebView` that loads the site on startup:
  - JavaScript, DOM Storage, database storage, and cookies (incl. third-party for
    Google Login) all enabled.
  - File upload (`<input type="file">`) via the system file picker.
  - Camera & microphone permission bridging (for `getUserMedia`/WebRTC features),
    requesting Android runtime permissions on demand.
  - Geolocation permission bridging (`onGeolocationPermissionsShowPrompt`).
  - Popup windows (`window.open`) opened inside the same WebView — never Chrome.
  - Downloads handled via Android's `DownloadManager` (saved to the Downloads folder),
    still without leaving the app.
  - Full-screen HTML5 `<video>` support (`onShowCustomView` / `onHideCustomView`).
  - Zoom controls disabled (`setSupportZoom(false)`).
  - A loading spinner while pages load, and a black-themed error screen with a
    **RETRY** button on network failure.
  - Android back button: goes back through WebView history first, then exits the app
    (or exits full-screen video first, if active).
  - `shouldOverrideUrlLoading` keeps every `http(s)` link inside the WebView; only
    non-http schemes (e.g. an `intent://` URL some OAuth flows use) are routed to a
    matching installed app, otherwise ignored — nothing opens in an external browser.
- **Orientation locked to Portrait** for both activities (in the manifest).
- **Material Components black theme**, no action bar, no toolbar, no bottom navigation —
  only the website is visible.
- App icon and splash screen use the two images you provided
  (`ic_logo.png` / launcher icon, `splash_background.png` / splash screen).

## Permissions declared

`INTERNET`, `ACCESS_NETWORK_STATE`, `CAMERA`, `RECORD_AUDIO`,
`ACCESS_FINE_LOCATION`, `ACCESS_COARSE_LOCATION`, plus scoped storage permissions
for older Android versions (file upload/download on API ≤ 32/28). Camera, mic, and
location are all *runtime*-requested only when the website actually asks for them,
which is standard Android/Play Store behavior.

## Notes

- `minSdk 24`, `targetSdk`/`compileSdk 34` (Android 14), Kotlin 1.9, AGP 8.2.
- `usesCleartextTraffic="false"` — the app only loads HTTPS, matching the target URL.
- Package/applicationId: `com.ucx.tournament`.
